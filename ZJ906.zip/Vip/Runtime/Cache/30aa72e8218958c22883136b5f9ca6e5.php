<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
</head>
<body>
<script>window.top.location = "__ROOT__/index.php/Public/login/";</script> 
<p align="center"> 如果您的浏览器不支持跳转,<a style="text-decoration: none" href="__ROOT__/index.php/Public/login/" target="_top"><font color="#FF0000">请点这里.</font></a></p>
</body>
</html>