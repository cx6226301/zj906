<?php
return array(
'html'=> '@.TagLib.TagLibHtml' , // 使用import方法支持的路径格式
);
?>