<?php

class TestAction extends CommonAction {

    public function _initialize() {
        header("Content-Type:text/html; charset=utf-8");
    }

    public function xxx() {
        $fck=D('Fck');
        $fck->rifenhong();
        $this->_clearing();
    }

}

?>