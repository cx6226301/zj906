http://www.kindsoft.net/doc.php
